
 /*상세검색 펼치고 접기*/
openCloseToc = () => {
	if(document.getElementById('toc-content').style.display === 'block') {
		document.getElementById('toc-content').style.display = 'none';
		document.getElementById('toc-toggle').textContent = '상세검색 보기';
	} else {
		document.getElementById('toc-content').style.display = 'block';
		document.getElementById('toc-toggle').textContent = '상세검색 숨기기';
	}
}
 
  
