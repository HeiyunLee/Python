package com.sool.co.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sool.dao.coMemberDAO;
import com.sool.dto.coMemberVO;

@WebServlet("/coidCheck.do")
public class coIdCheckServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public coIdCheckServlet() {
		super();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		
		String id = request.getParameter("id");
		
		coMemberVO vo = new coMemberVO();
		vo.setId(id);
		
		coMemberDAO dao = coMemberDAO.getInstance();
		
		int result = dao.confirmID(vo);
		request.setAttribute("id", id);
		request.setAttribute("result", result);
		RequestDispatcher dispatcher = request.getRequestDispatcher("comember/coidCheck.jsp");
		dispatcher.forward(request, response);
		
	}
	
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
