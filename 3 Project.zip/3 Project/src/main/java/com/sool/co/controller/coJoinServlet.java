package com.sool.co.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sool.dao.coMemberDAO;
import com.sool.dto.coMemberVO;



@WebServlet("/cojoin.do")
public class coJoinServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public coJoinServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = request
				.getRequestDispatcher("comember/cojoin.jsp");
		dispatcher.forward(request, response);
	}
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		//1. 데이터 가져오기
		String admin = request.getParameter("admin");
		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		String coName = request.getParameter("coName");
		String coNum = request.getParameter("coNum");
		String phone = request.getParameter("phone");
		String email = request.getParameter("email");
		
		
		coMemberVO vo = new coMemberVO();
		vo.setAdmin(Integer.parseInt(admin));
		vo.setId(id);
		vo.setPwd(pwd);
		vo.setCoName(coName);
		vo.setCoNum(coNum);
		vo.setPhone(phone);
		vo.setEmail(email);

		coMemberDAO dao = coMemberDAO.getInstance();
		
		int result = dao.insertMember(vo);
		HttpSession session = request.getSession();
		if (result == 1) {
			session.setAttribute("id", vo.getId());
			request.setAttribute("message", "회원 가입에 성공했습니다.");
		} else {
			request.setAttribute("message", "회원 가입에 실패했습니다.");
		}
		RequestDispatcher dispatcher = request
				.getRequestDispatcher("comember/cologin.jsp");
		dispatcher.forward(request, response);
		
		
	}

}
