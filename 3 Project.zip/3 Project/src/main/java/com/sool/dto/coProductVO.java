package com.sool.dto;

public class coProductVO {

}
