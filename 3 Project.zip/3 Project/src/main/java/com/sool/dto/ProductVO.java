package com.sool.dto;

public class ProductVO {

}
