package com.sool.dto;

public class MemberVO {
	private int admin;
	private String userid;
	private String pwd;
	private String name;
	private String gender;
	private String birth;
	private String email;
	private String prefer;
	
	

	public int getAdmin() {
		return admin;
	}

	public void setAdmin(int admin) {
		this.admin = admin;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getBirth() {
		return birth;
	}

	public void setBirth(String birth) {
		this.birth = birth;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPrefer() {
		return prefer;
	}

	public void setPrefer(String prefer) {
		this.prefer = prefer;
	}
	
	@Override
	public String toString() {
		return "MemberVO [admin=" + admin + ", userid=" + userid + ", pwd=" + pwd
				+ ", name=" + name + ", gender=" + gender + ", birth=" + birth + ", email=" + email + ", prefer=" + prefer
				+ "]";
	}
	
}
