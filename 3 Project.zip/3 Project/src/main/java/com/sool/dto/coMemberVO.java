package com.sool.dto;

public class coMemberVO {
	private int admin;
	private String id;
	private String pwd;
	private String coName;
	private String coNum;
	private String phone;
	private String email;
	
	public int getAdmin() {
		return admin;
	}
	
	public void setAdmin(int admin) {
		this.admin = admin;
	}
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public String getPwd() {
		return pwd;
	}
	
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
	public String getCoName() {
		return coName;
	}
	
	public void setCoName(String coName) {
		this.coName = coName;
	}
	
	public String getCoNum() {
		return coNum;
	}
	
	public void setCoNum(String coNum) {
		this.coNum = coNum;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	@Override
	public String toString() {
		return "coMemberVO [admin=" + admin + ", id=" + id + ", pwd=" + pwd
				+ ", coName=" + coName + ", coNum=" + coNum + ", phone=" + phone + ", email=" + email
				+ "]";
	}
	
}
