package com.sool.admin.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sool.dao.MemberDAO;
import com.sool.dao.coMemberDAO;
import com.sool.dto.MemberVO;
import com.sool.dto.coMemberVO;

/**
 * Servlet implementation class ProductDeleteServlet
 */
@WebServlet("/adminMemberDelete.do")
public class adminMemberDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public adminMemberDeleteServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String userid = request.getParameter("userid");
		MemberDAO dao = MemberDAO.getInstance();
		MemberVO vo = dao.getMember(userid);
		request.setAttribute("vo", vo);
		RequestDispatcher dispatcher = request
				.getRequestDispatcher("admin/adminMemberDelete.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8"); // 한글 깨짐을 방지
		
		String admin = request.getParameter("admin");
		String userid = request.getParameter("userid");
		String pwd = request.getParameter("pwd");
		String name = request.getParameter("name");
		String gender = request.getParameter("gender");
		String birth = request.getParameter("birth");
		String email = request.getParameter("email");
		String prefer = request.getParameter("prefer");
		
		MemberVO vo = new MemberVO();
		vo.setAdmin(Integer.parseInt(admin));
		vo.setUserid(userid);
		vo.setPwd(pwd);
		vo.setName(name);
		vo.setGender(gender);
		vo.setBirth(birth);
		vo.setEmail(email);
		vo.setPrefer(prefer);
				
		MemberDAO dao = MemberDAO.getInstance();
		dao.deleteMember(userid);
		response.sendRedirect("admin/adminMemberList.jsp");
	}

}
