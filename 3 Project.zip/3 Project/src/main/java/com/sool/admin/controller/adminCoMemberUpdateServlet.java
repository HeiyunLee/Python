package com.sool.admin.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sool.dao.coMemberDAO;
import com.sool.dto.coMemberVO;

/**
 * Servlet implementation class MemberUpdateServlet
 */
@WebServlet("/adminCoMemberUpdate.do")
public class adminCoMemberUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public adminCoMemberUpdateServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		coMemberDAO dao = coMemberDAO.getInstance();
		coMemberVO vo = dao.getMember(id);
		request.setAttribute("vo", vo);
		RequestDispatcher dispatcher = request
				.getRequestDispatcher("/admin/adminCoMemberUpdate.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8"); // 한글 깨짐을 방지
		
		String admin = request.getParameter("admin");
		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		String coName = request.getParameter("coName");
		String coNum = request.getParameter("coNum");
		String phone = request.getParameter("phone");
		String email = request.getParameter("email");
		
		coMemberVO vo = new coMemberVO();
		vo.setAdmin(Integer.parseInt(admin));
		vo.setId(id);
		vo.setPwd(pwd);
		vo.setCoName(coName);
		vo.setCoNum(coNum);
		vo.setPhone(phone);
		vo.setEmail(email);
				
		coMemberDAO dao = coMemberDAO.getInstance();
		dao.updateMember(vo);
		response.sendRedirect("adminCoMemberList.do");
	}

}