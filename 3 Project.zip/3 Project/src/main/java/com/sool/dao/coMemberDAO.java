package com.sool.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.sool.dao.coMemberDAO;
import com.sool.dto.MemberVO;
import com.sool.dto.coMemberVO;

public class coMemberDAO {
	private coMemberDAO() {
	}

	private static coMemberDAO instance = new coMemberDAO();

	public static coMemberDAO getInstance() {
		return instance;
	}
	
	// JDBC 코드 가지는 자료형
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;

	// 1.DB연결을 위한 메소드
	private void getConn() {
		// 1. 드라이브 동적 로딩
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			// 2. DB연결
			String url = "jdbc:mysql://project-db-stu.ddns.net:3307/seocho_0830_3?"
				      +"useUnicode=true&characterEncoding=utf-8";
			String id = "seocho_0830_3";
			String pw = "smhrd3";
			conn = DriverManager.getConnection(url, id, pw);
			System.out.println("DB연결성공");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("DB연결실패");
			e.printStackTrace();
		}
	}

	// 자원 반납 메소드
	private void getClose() {
		try {  //ctrl+shift+f 자동 정렬 완성
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if(conn != null)
				conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	

	// 사용자 인증시 사용하는 메소드
	public int userCheck(String id, String pwd) {
		int result = -1;
		String sql = "select pwd from coMember where id=?";
		try {
			getConn();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				if (rs.getString("pwd") != null
						&& rs.getString("pwd").equals(pwd)) {
					result = 1;
				} else {
					result = 0;
				}
			} else {
				result = -1;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	// 아이디로 회원 정보 가져오는 메소드
	
	public coMemberVO getMember(String id) {
		coMemberVO vo = null;
		String sql = "select * from coMember where id=?";
		try {
			getConn();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				vo = new coMemberVO();
				vo.setAdmin(rs.getInt("admin"));
				vo.setId(rs.getString("id"));
				vo.setPwd(rs.getString("pwd"));
				vo.setCoName(rs.getString("coName"));
				vo.setCoNum(rs.getString("coNum"));
				vo.setPhone(rs.getString("phone"));
				vo.setEmail(rs.getString("email"));
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return vo;
	}

	public int confirmID(coMemberVO vo) {
		int result = -1;
		String sql = "select id from coMember where id=?";
		try {
			getConn();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getId());
			rs = pstmt.executeQuery();
			if (rs.next()) {
				result = 1;
			} else {
				result = -1;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			getClose();
		}
		return result;
	}

	public int deletecoMember(String id) {
		int result = -1;
		String sql = "delete from coMember where id=?";
		try {
			getConn();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			result = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			getClose();
		}
		return result;
	}
	
	public int insertMember(coMemberVO vo) {		
		int result = -1;
		String sql = "insert into coMember values(?, ?, ?, ?, ?, ?, ?)";
		try {
			getConn();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, vo.getAdmin());
			pstmt.setString(2, vo.getId());
			pstmt.setString(3, vo.getPwd());
			pstmt.setString(4, vo.getCoName());
			pstmt.setString(5, vo.getCoNum());
			pstmt.setString(6, vo.getPhone());
			pstmt.setString(7, vo.getEmail());
			result = pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	public int updateMember(coMemberVO vo) {
		int result = -1;
		String sql = "update coMember set admin=?, pwd=?, coName=?, coNum=?, phone=?,"
				+ "email=? where id=?";
		try {
			getConn();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, vo.getAdmin());
			pstmt.setString(2, vo.getPwd());
			pstmt.setString(3, vo.getCoName());
			pstmt.setString(4, vo.getCoNum());
			pstmt.setString(5, vo.getPhone());
			pstmt.setString(6, vo.getEmail());
			pstmt.setString(7, vo.getId());
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result;
	}
	
	/* *
	 * 관리자 모드에서 사용되는 메소드 * *
	 */
	public ArrayList<coMemberVO> listMember(String id) {
		ArrayList<coMemberVO> comemberList = new ArrayList<coMemberVO>();
		String sql = "select * from coMember order by '?'";

		try {
			getConn();
			pstmt = conn.prepareStatement(sql);
			if (id == "") {
				pstmt.setString(1, "%");
			} else {
				pstmt.setString(1, id);
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				coMemberVO vo = new coMemberVO();
				vo.setAdmin(rs.getInt("admin"));
				vo.setId(rs.getString("id"));
				vo.setPwd(rs.getString("pwd"));
				vo.setCoName(rs.getString("coName"));
				vo.setCoNum(rs.getString("coNum"));
				vo.setPhone(rs.getString("phone"));
				vo.setEmail(rs.getString("email"));
		        comemberList.add(vo);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return comemberList;
	}
	
	// c Read u d
	public List<coMemberVO> selectAllcoMember() {
		// 최근 등록한 상품 먼저 출력하기
		String sql = "select * from coMember";
		List<coMemberVO> list = new ArrayList<coMemberVO>();
		
		try {
			getConn();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) { // 이동은 행(로우) 단위로
				coMemberVO vo = new coMemberVO();
				vo.setAdmin(rs.getInt("admin"));
				vo.setId(rs.getString("id"));
				vo.setPwd(rs.getString("pwd"));
				vo.setCoName(rs.getString("coName"));
				vo.setCoNum(rs.getString("coNum"));
				vo.setPhone(rs.getString("phone"));
				vo.setEmail(rs.getString("email"));
				list.add(vo);
			}// while문 끝
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return list;
	}
}
