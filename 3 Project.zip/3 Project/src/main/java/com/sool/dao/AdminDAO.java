package com.sool.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.sool.dao.AdminDAO;
import com.sool.dto.AdminVO;

public class AdminDAO {
	private AdminDAO() {
	}

	private static AdminDAO instance = new AdminDAO();

	public static AdminDAO getInstance() {
		return instance;
	}
	
	// JDBC 코드 가지는 자료형
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;

	// 1.DB연결을 위한 메소드
	private void getConn() {
		// 1. 드라이브 동적 로딩
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			// 2. DB연결
			String url = "jdbc:mysql://project-db-stu.ddns.net:3307/seocho_0830_3?"
				      +"useUnicode=true&characterEncoding=utf-8";
			String id = "seocho_0830_3";
			String pw = "smhrd3";
			conn = DriverManager.getConnection(url, id, pw);
			System.out.println("DB연결성공");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("DB연결실패");
			e.printStackTrace();
		}
	}

	// 자원 반납 메소드
	private void getClose() {
		try {  //ctrl+shift+f 자동 정렬 완성
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if(conn != null)
				conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	// 사용자 인증시 사용하는 메소드
	public int workerCheck(String id, String pwd) {
		int result = -1;
		String sql = "select pwd from worker where id=?";
		try {
			getConn();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				if (rs.getString("pwd") != null
						&& rs.getString("pwd").equals(pwd)) {
					result = 1;
				} else {
					result = 0;
				}
			} else {
				result = -1;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result;
	}
	// 아이디로 회원 정보 가져오는 메소드
	
	public AdminVO getMember(String id) {
		AdminVO vo = null;
		String sql = "select * from worker where id=?";
		try {
			getConn();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				vo = new AdminVO();
				vo.setId(rs.getString("id"));
				vo.setPwd(rs.getString("pwd"));
				vo.setName(rs.getString("name"));
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return vo;
	}

}