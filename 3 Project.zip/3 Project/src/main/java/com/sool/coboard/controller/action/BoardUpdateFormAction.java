package com.sool.coboard.controller.action;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sool.dao.coBoardDAO;
import com.sool.dto.coBoardVO;

public class BoardUpdateFormAction implements Action {
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String url = "/coBoard/boardUpdate.jsp";
		String num = request.getParameter("num");
		coBoardDAO bDao = coBoardDAO.getInstance();
		bDao.updateReadCount(num);
		coBoardVO bVo = bDao.selectOneBoardByNum(num);
		request.setAttribute("board", bVo);
		RequestDispatcher dispatcher = request.getRequestDispatcher(url);
		dispatcher.forward(request, response);
	}
}
