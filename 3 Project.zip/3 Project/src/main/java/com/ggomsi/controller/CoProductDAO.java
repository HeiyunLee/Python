package com.ggomsi.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.ggomsi.domain.CoProductVO;
import com.ggomsi.domain.ProductVO;

public class CoProductDAO {
	
	Connection con = null;
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	//DB연결메서드 구현
	private void getCon() throws Exception{
		Context init = new InitialContext();
		DataSource ds = (DataSource) init.lookup("java:comp/env/jdbc/mysql");
		con = ds.getConnection();
		System.out.println("디비연결성공 + con");
	}//getCon닫음
	
	//자원해제 메서드 구현
	public void closeDB(){
		try{
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(con != null) con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
	}//closeDB닫음
	
	public int getCoProductCount(){

		int count = 0;

		try {
			//디비연결
			getCon();
			//sql작성, pstmt
			sql = "select count(*) from coProduct";
			pstmt = con.prepareStatement(sql);
			//실행 -> rs저장
			rs = pstmt.executeQuery();
			//데이터처리
			if(rs.next()){
				count = rs.getInt(1);
				System.out.println("게시판 글 갯수 확인 :"+ count);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeDB();
		}
		return count;
	}
	
public List<CoProductVO> getCoProductList(){
	//가변길이 배열 생성
	List<CoProductVO> CoproductList = new ArrayList<CoProductVO>(); 

	try {
		
		getCon();

		sql = "select * from coProduct order by gName";
		pstmt = con.prepareStatement(sql);
		//3. 실행 -> rs저장
		rs = pstmt.executeQuery();
		//4. 데이터처리
		//정보의 갯수가 몇개인지 모르기때문에 while 반복문을 사용
		while(rs.next()){
			
			CoProductVO bb = new CoProductVO();
			
			bb.setcCode(rs.getString("cCode"));
			bb.setId(rs.getString("id"));
			bb.setgName(rs.getString("gName"));
			bb.setMaker(rs.getString("maker"));
			bb.setKind(rs.getString("kind"));
			bb.setVol(rs.getString("vol"));
			bb.setPrice(rs.getString("price"));
			bb.setAward(rs.getString("award"));
			bb.setIngre(rs.getString("ingre"));
			bb.setQtity(rs.getString("qtity"));
			bb.setInfo(rs.getString("info"));
			bb.setFood(rs.getString("food"));
			bb.setHomepage(rs.getString("homepage"));
			bb.setAddr(rs.getString("addr"));
			bb.setTag(rs.getString("tag"));
			bb.setEx(rs.getString("ex"));
			bb.setPhone(rs.getString("phone"));
			bb.setApp(rs.getString("app"));

			//여기까지가 한 행의 데이터를 저장한 것임. while로 모든 행을 반복

			//가변배열(ArrayList)에 위의 데이터 저장
			//즉 배열 한칸에 상품 하나의 정보를 저장함.
			CoproductList.add(bb); //업캐스팅
		}
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		closeDB();
	}
	return CoproductList;
}
	
	//DB에서 상품 전체 가져오는데 페이징처리한 메서드 구현 (메서드 오버로딩)
public List<CoProductVO> getCoProductList(int startRow, int pageSize){
	//가변길이 배열 생성
	List<CoProductVO> CoproductList = new ArrayList<>();

	try {
		//1. 디비연결
		getCon();

		sql = "select * from coProduct order by cCode limit ?,?";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, startRow-1);
		pstmt.setInt(2, pageSize);
		//3. 실행 -> rs저장
		rs = pstmt.executeQuery();
		
		while(rs.next()) {
			
			CoProductVO bb = new CoProductVO();
			bb.setcCode(rs.getString("cCode"));
			bb.setId(rs.getString("id"));
			bb.setgName(rs.getString("gName"));
			bb.setMaker(rs.getString("maker"));
			bb.setKind(rs.getString("kind"));
			bb.setVol(rs.getString("vol"));
			bb.setPrice(rs.getString("price"));
			bb.setAward(rs.getString("award"));
			bb.setIngre(rs.getString("ingre"));
			bb.setQtity(rs.getString("qtity"));
			bb.setInfo(rs.getString("info"));
			bb.setFood(rs.getString("food"));
			bb.setHomepage(rs.getString("homepage"));
			bb.setAddr(rs.getString("addr"));
			bb.setTag(rs.getString("tag"));
			bb.setEx(rs.getString("ex"));
			bb.setPhone(rs.getString("phone"));
			bb.setApp(rs.getString("app"));
			
			CoproductList.add(bb); //업캐스팅
			
		}
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		closeDB();
	}
	return CoproductList;
}


public CoProductVO getCoProduct(String cCode){
	 //rs에 데이터가 없으면 객체생성할 필요가 없음. 따라서 객채생성안하고 null함.
	CoProductVO bb = null;
	try {
		
		getCon();

		sql = "select * from coProduct where cCode=?";
		pstmt = con.prepareStatement(sql);
		pstmt.setString(1, cCode);
		//3. 실행 -> rs저장
		rs = pstmt.executeQuery();
		//4. 데이터처리
		if(rs.next()){
			
			bb = new CoProductVO(); 
			bb.setcCode(rs.getString("cCode"));
			bb.setId(rs.getString("id"));
			bb.setgName(rs.getString("gName"));
			bb.setMaker(rs.getString("maker"));
			bb.setKind(rs.getString("kind"));
			bb.setVol(rs.getString("vol"));
			bb.setPrice(rs.getString("price"));
			bb.setAward(rs.getString("award"));
			bb.setIngre(rs.getString("ingre"));
			bb.setQtity(rs.getString("qtity"));
			bb.setInfo(rs.getString("info"));
			bb.setFood(rs.getString("food"));
			bb.setHomepage(rs.getString("homepage"));
			bb.setAddr(rs.getString("addr"));
			bb.setTag(rs.getString("tag"));
			bb.setEx(rs.getString("ex"));
			bb.setPhone(rs.getString("phone"));
			bb.setApp(rs.getString("app"));
			//여기까지가 한 행의 데이터를 저장한 것임
		}
		
		
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		closeDB();
	}	
	return bb;
}

//상품추가
public int insertProduct(CoProductVO bdto){
	int result = 0;
	int gCode_int = 0;
	String cCode_str = "";
	
	try {
		getCon(); // con 인스턴스 변수에 저장완료
		
		sql = "select max(cCode) from coProduct";
		pstmt = con.prepareStatement(sql);
		rs = pstmt.executeQuery();
		if(rs.next()){
			String gCode_str = rs.getString("max(cCode)");
			String A = gCode_str.replaceAll("[1-9]*", "");
			String gCode_str_1 = gCode_str.replaceAll("[^0-9]", "");
			String gCode_str_2 = gCode_str_1.replaceAll("[0]*", "");
			gCode_int = Integer.parseInt(gCode_str_2)+1;
			gCode_str = Integer.toString(gCode_int);
			cCode_str = A+gCode_str;
			
		}
		System.out.println("DAO : 새로운 cCode= "+ cCode_str);
		sql ="insert into coProduct(cCode, id, gName, maker, kind, vol, price, award, ingre, qtity, info, food, homepage, addr, tag, ex, phone, app)"
				+ " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		pstmt = con.prepareStatement(sql);
		pstmt.setString(1, cCode_str);
		pstmt.setString(2, bdto.getId());
		pstmt.setString(3, bdto.getgName());
		pstmt.setString(4, bdto.getMaker());
		pstmt.setString(5, bdto.getKind());
		pstmt.setString(6, bdto.getVol()); 
		pstmt.setString(7, bdto.getPrice()); 
		pstmt.setString(8, bdto.getAward()); 
		pstmt.setString(9, bdto.getIngre()); 
		pstmt.setString(10, bdto.getQtity());
		pstmt.setString(11, bdto.getInfo());
		pstmt.setString(12, bdto.getFood());
		pstmt.setString(13, bdto.getHomepage());
		pstmt.setString(14, bdto.getAddr());
		pstmt.setString(15, bdto.getTag());
		pstmt.setString(16, bdto.getEx());
		pstmt.setString(17, bdto.getPhone());
		pstmt.setString(18, bdto.getApp());
		// 실행			
		result = pstmt.executeUpdate();
		System.out.println("DAO : 상품 등록완료! ");
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		closeDB();
	}
	return result;
}

public int insertCoProduct(String gName, String maker, String kind, String vol, String price, String award, String ingre, String qtity, String info, String food, String homepage, String addr, String tag, String ex, String phone){
	int result = 0;
	int gCode_int = 0;
	String cCode_str = "";
	CoProductVO bb = null;
	try {
		getCon(); // con 인스턴스 변수에 저장완료
		
		sql = "select max(gCode) from Product";
		pstmt = con.prepareStatement(sql);
		rs = pstmt.executeQuery();
		if(rs.next()){
			String gCode_str = rs.getString("max(gCode)");
			String A = gCode_str.replaceAll("[1-9]*", "");
			String gCode_str_1 = gCode_str.replaceAll("[^0-9]", "");
			String gCode_str_2 = gCode_str_1.replaceAll("[0]*", "");
			gCode_int = Integer.parseInt(gCode_str_2)+1;
			gCode_str = Integer.toString(gCode_int);
			cCode_str = A+gCode_str;
			
		}
		System.out.println("DAO : 새로운 gCode= "+ cCode_str);
		sql ="insert into Product(gCode, gName, maker, kind, vol, price, award, ingre, qtity, info, food, homepage, addr, tag, ex, phone)"
				+ " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		pstmt = con.prepareStatement(sql);
		pstmt.setString(1, cCode_str);
		pstmt.setString(2, gName);
		pstmt.setString(3, maker);
		pstmt.setString(4, kind);
		pstmt.setString(5, vol); 
		pstmt.setString(6, price); 
		pstmt.setString(7, award); 
		pstmt.setString(8, ingre); 
		pstmt.setString(9, qtity);
		pstmt.setString(10, info);
		pstmt.setString(11, food);
		pstmt.setString(12, homepage);
		pstmt.setString(13, addr);
		pstmt.setString(14, tag);
		pstmt.setString(15, ex);
		pstmt.setString(16, phone);

		// 실행			
		result = pstmt.executeUpdate();
		System.out.println("DAO : 상품 등록완료! ");
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		closeDB();
	}
	return result;
}

public int deleteCoProduct(String cCode){
	int result = 0;
	CoProductVO bb = null;
	try {
		getCon(); // con 인스턴스 변수에 저장완료
		sql ="delete from coProduct where cCode = ?";
		pstmt = con.prepareStatement(sql);
		pstmt.setString(1, cCode);
		// 실행			
		result = pstmt.executeUpdate();
		System.out.println("DAO : 상품 제거완료! ");
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		closeDB();
	}
	return result;
}



}