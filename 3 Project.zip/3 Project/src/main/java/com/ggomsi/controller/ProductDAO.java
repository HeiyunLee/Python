package com.ggomsi.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.ggomsi.domain.ProductVO;

public class ProductDAO {
	
	Connection con = null;
	String sql = "";
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	

	private void getCon() throws Exception{
		Context init = new InitialContext(); //업캐스팅
		DataSource ds = (DataSource) init.lookup("java:comp/env/jdbc/mysql");
		con = ds.getConnection();
		System.out.println("디비연결성공 + con");
	}//getCon닫음
	
	//자원해제 메서드 구현
	public void closeDB(){
		try{
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(con != null) con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
	}//closeDB닫음
	
	public int getProductCount(){

		int count = 0;

		try {
			getCon();
			sql = "select count(*) from Product";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			//데이터처리
			if(rs.next()){
				count = rs.getInt(1); // 데이터가 없으면 null이고 return 0값이 된다.
				//count = rs.getInt("count(*)"); 위와 동일한 결과
				System.out.println("게시판 글 갯수 확인 :"+ count);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeDB();
		}
		return count;
	}
	
public List<ProductVO> getProductList(){
	//가변길이 배열 생성
	List<ProductVO> productList = new ArrayList<ProductVO>(); 

	try {
		//1. 디비연결
		getCon();
		sql = "select * from Product order by gName";
		pstmt = con.prepareStatement(sql);
		//3. 실행 -> rs저장
		rs = pstmt.executeQuery();
		//4. 데이터처리
		//정보의 갯수가 몇개인지 모르기때문에 while 반복문을 사용
		while(rs.next()){

			ProductVO bb = new ProductVO();
			bb.setgCode(rs.getString("gCode"));
			bb.setgName(rs.getString("gName"));
			bb.setMaker(rs.getString("maker"));
			bb.setKind(rs.getString("kind"));
			bb.setVol(rs.getString("vol"));
			bb.setPrice(rs.getString("price"));
			bb.setAward(rs.getString("award"));
			bb.setIngre(rs.getString("ingre"));
			bb.setQtity(rs.getString("qtity"));
			bb.setInfo(rs.getString("info"));
			bb.setFood(rs.getString("food"));
			bb.setHomepage(rs.getString("homepage"));
			bb.setAddr(rs.getString("addr"));
			bb.setTag(rs.getString("tag"));
			bb.setEx(rs.getString("ex"));
			bb.setPhone(rs.getString("phone"));

			//여기까지가 한 행의 데이터를 저장한 것임. while로 모든 행을 반복

			//가변배열(ArrayList)에 위의 데이터 저장
			//즉 배열 한칸에 상품 하나의 정보를 저장함.
			productList.add(bb); //업캐스팅
		}
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		closeDB();
	}
	return productList;
}


	
public List<ProductVO> getProductList(int startRow, int pageSize){
	//가변길이 배열 생성
	List<ProductVO> productList = new ArrayList<>();

	try {
		//1. 디비연결
		getCon();

		sql = "select * from Product order by gCode limit ?,?";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, startRow-1);
		pstmt.setInt(2, pageSize);
		//3. 실행 -> rs저장
		rs = pstmt.executeQuery();
		
		while(rs.next()) {
			
			ProductVO bb = new ProductVO();
			bb.setgCode(rs.getString("gCode"));
			bb.setgName(rs.getString("gName"));
			bb.setMaker(rs.getString("maker"));
			bb.setKind(rs.getString("kind"));
			bb.setVol(rs.getString("vol"));
			bb.setPrice(rs.getString("price"));
			bb.setAward(rs.getString("award"));
			bb.setIngre(rs.getString("ingre"));
			bb.setQtity(rs.getString("qtity"));
			bb.setInfo(rs.getString("info"));
			bb.setFood(rs.getString("food"));
			bb.setHomepage(rs.getString("homepage"));
			bb.setAddr(rs.getString("addr"));
			bb.setTag(rs.getString("tag"));
			bb.setEx(rs.getString("ex"));
			bb.setPhone(rs.getString("phone"));
			
			productList.add(bb); //업캐스팅
			
		}
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		closeDB();
	}
	return productList;
}

public int getSearchCount(String findStr){

	int count = 0;

	try {
		getCon();
		sql = "select count(*) from Product where gName like ? or maker like ?";
		pstmt = con.prepareStatement(sql);
		pstmt.setString(1, '%'+findStr+'%');
		pstmt.setString(2, '%'+findStr+'%');
		rs = pstmt.executeQuery();
		//데이터처리
		if(rs.next()){
			count = rs.getInt(1); // 데이터가 없으면 null이고 return 0값이 된다.
			//count = rs.getInt("count(*)"); 위와 동일한 결과
			System.out.println("검색 상품 개수 확인 :"+ count);
		}
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		closeDB();
	}
	return count;
}


public List<ProductVO> getSearchProduct(){
	//가변길이 배열 생성
	List<ProductVO> productList = new ArrayList<ProductVO>(); 
	
	try {
		//1. 디비연결
		getCon();
		sql = "select * from Product where gName like ? or maker like ?";
		pstmt = con.prepareStatement(sql);
		//3. 실행 -> rs저장
		rs = pstmt.executeQuery();
		//4. 데이터처리
		//정보의 갯수가 몇개인지 모르기때문에 while 반복문을 사용
		while(rs.next()){

			ProductVO bb = new ProductVO();
			bb.setgCode(rs.getString("gCode"));
			bb.setgName(rs.getString("gName"));
			bb.setMaker(rs.getString("maker"));
			bb.setKind(rs.getString("kind"));
			bb.setVol(rs.getString("vol"));
			bb.setPrice(rs.getString("price"));
			bb.setAward(rs.getString("award"));
			bb.setIngre(rs.getString("ingre"));
			bb.setQtity(rs.getString("qtity"));
			bb.setInfo(rs.getString("info"));
			bb.setFood(rs.getString("food"));
			bb.setHomepage(rs.getString("homepage"));
			bb.setAddr(rs.getString("addr"));
			bb.setTag(rs.getString("tag"));
			bb.setEx(rs.getString("ex"));
			bb.setPhone(rs.getString("phone"));

			//여기까지가 한 행의 데이터를 저장한 것임. while로 모든 행을 반복

			//가변배열(ArrayList)에 위의 데이터 저장
			//즉 배열 한칸에 상품 하나의 정보를 저장함.
			productList.add(bb); //업캐스팅
		}
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		closeDB();
	}
	return productList;
}

public int getSearchCount(String findStr, String kind, String vol, String award){

	int count = 0;

	try {
		getCon();
		String dosu = "";
		String jong = "";
		String sang = "";
		if(vol.equals("1")) {
			for(int i=1; i<=5; i++) {
				dosu += " or (vol LIKE '"+i+"%' ESCAPE '%' or vol like'"+i+"%.%')";
			}
		}else if(vol.equals("5")) {
			for(int i=5; i<=15; i++) {
				dosu += " or (vol LIKE '"+i+"%' ESCAPE '%' or vol like'"+i+"%.%')";
			}
		}else if(vol.equals("15")) {
			for(int i=15; i<=25; i++) {
				dosu += " or (vol LIKE '"+i+"%' ESCAPE '%' or vol like'"+i+"%.%')";
			} 
		}else if(vol.equals("25")) {
			for(int i=25; i<=35; i++) {
				dosu += " or (vol LIKE '"+i+"%' ESCAPE '%' or vol like'"+i+"%.%')";
			}
		}else if(vol.equals("35")) {
			for(int i=35; i<=55; i++) {
				dosu += " or (vol LIKE '"+i+"%' ESCAPE '%' or vol like'"+i+"%.%')";
			}
		}else {
			dosu = "";
		}
		if(kind != null) {
			jong = " and kind = '"+kind+"'";
		}
		if(award.equals("0")) {
			sang = " and award = ''";
		}
		sql = "select count(*) from Product where (gName like ? or maker like ?)" + jong + sang + dosu;
		System.out.println(sql);
		pstmt = con.prepareStatement(sql);
		pstmt.setString(1, '%'+findStr+'%');
		pstmt.setString(2, '%'+findStr+'%');
		rs = pstmt.executeQuery();
		//데이터처리
		if(rs.next()){
			count = rs.getInt(1); // 데이터가 없으면 null이고 return 0값이 된다.
			//count = rs.getInt("count(*)"); 위와 동일한 결과
			System.out.println("검색 상품 개수 확인 :"+ count);
		}
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		closeDB();
	}
	return count;
}


public List<ProductVO> getSearchProduct(int startRow, int pageSize, String findStr, String kind, String vol, String award){
	//가변길이 배열 생성
	List<ProductVO> productList = new ArrayList<>();

	try {
		//1. 디비연결
		getCon();
		String dosu = "";
		String jong = "";
		String sang = "";
		if(vol.equals("1")) {
			for(int i=1; i<=5; i++) {
				dosu += " or (vol LIKE '"+i+"%' ESCAPE '%' or vol like'"+i+"%.%')";
			}
		}else if(vol.equals("5")) {
			for(int i=5; i<=15; i++) {
				dosu += " or (vol LIKE '"+i+"%' ESCAPE '%' or vol like'"+i+"%.%')";
			}
		}else if(vol.equals("15")) {
			for(int i=15; i<=25; i++) {
				dosu += " or (vol LIKE '"+i+"%' ESCAPE '%' or vol like'"+i+"%.%')";
			} 
		}else if(vol.equals("25")) {
			for(int i=25; i<=35; i++) {
				dosu += " or (vol LIKE '"+i+"%' ESCAPE '%' or vol like'"+i+"%.%')";
			}
		}else if(vol.equals("35")) {
			for(int i=35; i<=55; i++) {
				dosu += " or (vol LIKE '"+i+"%' ESCAPE '%' or vol like'"+i+"%.%')";
			}
		}else {
			dosu = "";
		}
		if(kind != null) {
			jong = " and kind = '"+kind+"'";
		}
		if(award.equals("0")) {
			sang = " and award = ''";
		}
		sql = "select * from Product where (gName like ? or maker like ?)" + jong + sang + dosu + " limit ?,?";
		System.out.println(sql);
		pstmt = con.prepareStatement(sql);
		System.out.println(findStr);
		pstmt.setString(1, '%'+findStr+'%');
		pstmt.setString(2, '%'+findStr+'%');
		pstmt.setInt(3, startRow-1);
		pstmt.setInt(4, pageSize);
		//3. 실행 -> rs저장
		rs = pstmt.executeQuery();
		
		while(rs.next()) {
			
			ProductVO bb = new ProductVO();
			bb.setgCode(rs.getString("gCode"));
			bb.setgName(rs.getString("gName"));
			bb.setMaker(rs.getString("maker"));
			bb.setKind(rs.getString("kind"));
			bb.setVol(rs.getString("vol"));
			bb.setPrice(rs.getString("price"));
			bb.setAward(rs.getString("award"));
			bb.setIngre(rs.getString("ingre"));
			bb.setQtity(rs.getString("qtity"));
			bb.setInfo(rs.getString("info"));
			bb.setFood(rs.getString("food"));
			bb.setHomepage(rs.getString("homepage"));
			bb.setAddr(rs.getString("addr"));
			bb.setTag(rs.getString("tag"));
			bb.setEx(rs.getString("ex"));
			bb.setPhone(rs.getString("phone"));
			
			productList.add(bb); //업캐스팅
			
		}
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		closeDB();
	}
	return productList;
}


public List<ProductVO> getSearchProduct(int startRow, int pageSize, String findStr){
	//가변길이 배열 생성
	List<ProductVO> productList = new ArrayList<>();

	try {
		//1. 디비연결
		getCon();
		sql = "select * from Product where gName like ? or maker like ? limit ?,?";
		pstmt = con.prepareStatement(sql);
		System.out.println(findStr);
		pstmt.setString(1, '%'+findStr+'%');
		pstmt.setString(2, '%'+findStr+'%');
		pstmt.setInt(3, startRow-1);
		pstmt.setInt(4, pageSize);
		//3. 실행 -> rs저장
		rs = pstmt.executeQuery();
		
		while(rs.next()) {
			
			ProductVO bb = new ProductVO();
			bb.setgCode(rs.getString("gCode"));
			bb.setgName(rs.getString("gName"));
			bb.setMaker(rs.getString("maker"));
			bb.setKind(rs.getString("kind"));
			bb.setVol(rs.getString("vol"));
			bb.setPrice(rs.getString("price"));
			bb.setAward(rs.getString("award"));
			bb.setIngre(rs.getString("ingre"));
			bb.setQtity(rs.getString("qtity"));
			bb.setInfo(rs.getString("info"));
			bb.setFood(rs.getString("food"));
			bb.setHomepage(rs.getString("homepage"));
			bb.setAddr(rs.getString("addr"));
			bb.setTag(rs.getString("tag"));
			bb.setEx(rs.getString("ex"));
			bb.setPhone(rs.getString("phone"));
			
			productList.add(bb); //업캐스팅
			
		}
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		closeDB();
	}
	return productList;
}


// 상세보기
public ProductVO getProduct(String gCode){
	 //rs에 데이터가 없으면 객체생성할 필요가 없음. 따라서 객채생성안하고 null함.
	ProductVO bb = null;
	try {
		//1. 디비연결
		getCon();
		sql = "select * from Product where gCode=?";
		pstmt = con.prepareStatement(sql);
		pstmt.setString(1, gCode);
		//3. 실행 -> rs저장
		rs = pstmt.executeQuery();
		//4. 데이터처리
		if(rs.next()){
			
			bb = new ProductVO(); 
			bb.setgCode(rs.getString("gCode"));
			bb.setgName(rs.getString("gName"));
			bb.setMaker(rs.getString("maker"));
			bb.setKind(rs.getString("kind"));
			bb.setVol(rs.getString("vol"));
			bb.setPrice(rs.getString("price"));
			bb.setAward(rs.getString("award"));
			bb.setIngre(rs.getString("ingre"));
			bb.setQtity(rs.getString("qtity"));
			bb.setInfo(rs.getString("info"));
			bb.setFood(rs.getString("food"));
			bb.setHomepage(rs.getString("homepage"));
			bb.setAddr(rs.getString("addr"));
			bb.setTag(rs.getString("tag"));
			bb.setEx(rs.getString("ex"));
			bb.setPhone(rs.getString("phone"));
			//여기까지가 한 행의 데이터를 저장한 것임
		}
		
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		closeDB();
	}	
	return bb;
}
}