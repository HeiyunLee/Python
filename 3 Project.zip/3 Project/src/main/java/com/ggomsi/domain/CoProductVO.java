package com.ggomsi.domain;

public class CoProductVO {
	//2번규칙만족 : 멤버변수선언 private
		private String cCode;
		private String id;
		private String gName;
		private String maker;
		private String kind;
		private String vol;
		private String price;
		private String award;
		private String ingre;
		private String qtity;
		private String info;
		private String food;
		private String homepage;
		private String addr;
		private String tag;
		private String ex;
		private String phone;
		private String app;
		
		

		
		public String getcCode() {
			return cCode;
		}

		public void setcCode(String gCode) {
			this.cCode = gCode;
		}
		
		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}
		public String getgName() {
			return gName;
		}

		public void setgName(String gName) {
			this.gName = gName;
		}

		public String getMaker() {
			return maker;
		}

		public void setMaker(String maker) {
			this.maker = maker;
		}

		public String getKind() {
			return kind;
		}

		public void setKind(String kind) {
			this.kind = kind;
		}

		public String getVol() {
			return vol;
		}

		public void setVol(String vol) {
			this.vol = vol;
		}

		public String getPrice() {
			return price;
		}

		public void setPrice(String price) {
			this.price = price;
		}

		public String getAward() {
			return award;
		}

		public void setAward(String award) {
			this.award = award;
		}

		public String getIngre() {
			return ingre;
		}

		public void setIngre(String ingre) {
			this.ingre = ingre;
		}

		public String getQtity() {
			return qtity;
		}

		public void setQtity(String qtity) {
			this.qtity = qtity;
		}

		public String getInfo() {
			return info;
		}

		public void setInfo(String info) {
			this.info = info;
		}

		public String getFood() {
			return food;
		}

		public void setFood(String food) {
			this.food = food;
		}

		public String getHomepage() {
			return homepage;
		}

		public void setHomepage(String homepage) {
			this.homepage = homepage;
		}

		public String getAddr() {
			return addr;
		}

		public void setAddr(String addr) {
			this.addr = addr;
		}

		public String getTag() {
			return tag;
		}

		public void setTag(String tag) {
			this.tag = tag;
		}

		public String getEx() {
			return ex;
		}

		public void setEx(String ex) {
			this.ex = ex;
		}

		public String getPhone() {
			return phone;
		}

		public void setPhone(String phone) {
			this.phone = phone;
		}
		
		public String getApp() {
			return app;
		}

		public void setApp(String app) {
			this.app = app;
		}


		
		//4번규칙만족 : 기본생성자존재하지만 생략됨
		//public BoardBean(){}
		
		//3번규칙만족 : 멤버변수마다 별도의 get/set메소드가 존재해야한다.
		

		//5. toString()
		@Override
		public String toString() {
			return "ProductVO [gCode= " + cCode + ", gName=" + gName +", id=" + id +", maker=" + maker + 
					",kind=" + kind + ", vol=" + vol + ", price=" + price +
					", award=" + award + ", ingre=" + ingre + ", qtity=" + qtity +
					", info=" + info + ", food=" + food + ", homepage=" + homepage + 
					",addr=" + addr + ",tag=" + tag + ",ex=" + ex + ",phone=" + phone + ",app=" + app +"]";
		}
}
